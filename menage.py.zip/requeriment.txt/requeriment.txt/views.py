# relatorios/views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from ocorrencias.models import Ocorrencia
from core.models import TipoViolacao, User
from django.utils import timezone
from datetime import timedelta
@login_required
def dashboard(request):
    hoje = timezone.now().date()
    inicio_mes = hoje.replace(day=1)
    inicio_ano = hoje.replace(month=1, day=1)
    
    # Estatísticas gerais
    total_ocorrencias = Ocorrencia.objects.count()
    ocorrencias_mes = Ocorrencia.objects.filter(data_registro__date__gte=inicio_mes).count()
    ocorrencias_pendentes = Ocorrencia.objects.filter(status__in=['registrada', 'andamento']).count()
    ocorrencias_resolvidas = Ocorrencia.objects.filter(status='resolvida').count()
    
    # Ocorrências por status
    status_stats = Ocorrencia.objects.values('status').annotate(
        count=Count('id')
    ).order_by('-count')
    
    # Ocorrências por tipo de violação
    tipo_stats = TipoViolacao.objects.annotate(
        count=Count('ocorrencia')
    ).order_by('-count')[:5]
    
    # Carga de trabalho por conselheira
    conselheiras_stats = User.objects.filter(
        perfil='conselheira',
        ativo=True
    ).annotate(
        casos_ativos=Count('ocorrencia', filter=Q(ocorrencia__status__in=['registrada', 'andamento'])),
        casos_resolvidos=Count('ocorrencia', filter=Q(ocorrencia__status='resolvida'))
    ).order_by('-casos_ativos')
    
    context = {
        'total_ocorrencias': total_ocorrencias,
        'ocorrencias_mes': ocorrencias_mes,
        'ocorrencias_pendentes': ocorrencias_pendentes,
        'ocorrencias_resolvidas': ocorrencias_resolvidas,
        'status_stats': status_stats,
        'tipo_stats': tipo_stats,
        'conselheiras_stats': conselheiras_stats,
    }
    
    return render(request, 'relatorios/dashboard.html', context)

@login_required
def estatisticas(request):
    # Relatório mais detalhado
    return render(request, 'relatorios/estatisticas.html')

# management/commands/setup_initial_data.py
from django.core.management.base import BaseCommand
from core.models import TipoViolacao, Bairro
from django.contrib.auth import get_user_model

User = get_user_model()

class Command(BaseCommand):
    help = 'Configura dados iniciais do sistema'
    
    def handle(self, *args, **options):
        # Criar tipos de violação baseados no ECA
        tipos_violacao = [
            {'codigo': 'NEG', 'nome': 'Negligência', 'descricao': 'Omissão dos responsáveis em prover necessidades básicas'},
            {'codigo': 'ABN', 'nome': 'Abandono', 'descricao': 'Abandono material ou afetivo da criança/adolescente'},
            {'codigo': 'VFS', 'nome': 'Violência Física', 'descricao': 'Agressão física contra criança/adolescente'},
            {'codigo': 'VPS', 'nome': 'Violência Psicológica', 'descricao': 'Agressão verbal, humilhação, ameaças'},
            {'codigo': 'VSX', 'nome': 'Violência Sexual', 'descricao': 'Abuso sexual contra criança/adolescente'},
            {'codigo': 'ETI', 'nome': 'Exploração do Trabalho Infantil', 'descricao': 'Trabalho infantil irregular ou perigoso'},
            {'codigo': 'DRG', 'nome': 'Uso/Tráfico de Substâncias', 'descricao': 'Envolvimento com drogas lícitas ou ilícitas'},
            {'codigo': 'ESC', 'nome': 'Evasão Escolar', 'descricao': 'Abandono ou irregularidade escolar'},
            {'codigo': 'OUT', 'nome': 'Outros', 'descricao': 'Outras violações não especificadas acima'},
        ]
        
        for tipo_data in tipos_violacao:
            tipo, created = TipoViolacao.objects.get_or_create(
                codigo=tipo_data['codigo'],
                defaults={
                    'nome': tipo_data['nome'],
                    'descricao': tipo_data['descricao']
                }
            )
            if created:
                self.stdout.write(f'Tipo de violação criado: {tipo.nome}')
        
        # Criar alguns bairros de Campo Grande, MS como exemplo
        bairros_exemplo = [
            {'nome': 'Centro', 'ceps': '79002-000,79003-000,79004-000'},
            {'nome': 'Amambaí', 'ceps': '79005-000,79006-000'},
            {'nome': 'São Francisco', 'ceps': '79010-000,79011-000'},
            {'nome': 'Vila Alba', 'ceps': '79016-000'},
            {'nome': 'Coophavila II', 'ceps': '79040-000,79041-000'},
            {'nome': 'Nova Lima', 'ceps': '79050-000,79051-000'},
            {'nome': 'Jardim dos Estados', 'ceps': '79020-000,79021-000'},
            {'nome': 'Vila Planalto', 'ceps': '79030-000'},
        ]
        
        for bairro_data in bairros_exemplo:
            bairro, created = Bairro.objects.get_or_create(
                nome=bairro_data['nome'],
                defaults={'ceps': bairro_data['ceps']}
            )
            if created:
                self.stdout.write(f'Bairro criado: {bairro.nome}')
        
        # Criar usuário administrador padrão
        if not User.objects.filter(username='admin').exists():
            admin_user = User.objects.create_superuser(
                username='admin',
                email='admin@conselhotutelar.gov.br',
                password='admin123',
                perfil='admin',
                first_name='Administrador',
                last_name='Sistema'
            )
            self.stdout.write('Usuário administrador criado: admin/admin123')
        
        self.stdout.write(self.style.SUCCESS('Dados iniciais configurados com sucesso!'))

# templates/base.html
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Sistema Conselho Tutelar{% endblock %}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #2c3e50;
        }
        .sidebar .nav-link {
            color: #ecf0f1;
        }
        .sidebar .nav-link:hover {
            background-color: #34495e;
            color: white;
        }
        .sidebar .nav-link.active {
            background-color: #3498db;
            color: white;
        }
        .main-content {
            padding: 20px;
        }
        .status-badge {
            font-size: 0.8em;
        }
        .priority-badge {
            font-size: 0.7em;
        }
        .card-ocorrencia {
            transition: transform 0.2s;
        }
        .card-ocorrencia:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block sidebar">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <h4 class="text-white">Conselho Tutelar</h4>
                        <small class="text-muted">{{ user.get_full_name }}</small>
                    </div>
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="{% url 'relatorios:dashboard' %}">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{% url 'ocorrencias:lista' %}">
                                <i class="fas fa-list"></i> Ocorrências
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{% url 'ocorrencias:nova' %}">
                                <i class="fas fa-plus"></i> Nova Ocorrência
                            </a>
                        </li>
                        {% if user.perfil == 'admin' or user.perfil == 'coordenador' %}
                        <li class="nav-item">
                            <a class="nav-link" href="{% url 'usuarios:lista' %}">
                                <i class="fas fa-users"></i> Usuários
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{% url 'usuarios:bairros' %}">
                                <i class="fas fa-map"></i> Bairros
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{% url 'usuarios:tipos_violacao' %}">
                                <i class="fas fa-exclamation-triangle"></i> Tipos de Violação
                            </a>
                        </li>
                        {% endif %}
                        <li class="nav-item">
                            <a class="nav-link" href="{% url 'relatorios:estatisticas' %}">
                                <i class="fas fa-chart-bar"></i> Relatórios
                            </a>
                        </li>
                    </ul>
                    
                    <hr class="my-3">
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="{% url 'usuarios:perfil' %}">
                                <i class="fas fa-user"></i> Meu Perfil
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{% url 'logout' %}">
                                <i class="fas fa-sign-out-alt"></i> Sair
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
            
            <!-- Main content -->
            <main class="col-md-10 ms-sm-auto col-lg-10 px-md-4 main-content">
                {% if messages %}
                    {% for message in messages %}
                    <div class="alert alert-{{ message.tags }} alert-dismissible fade show" role="alert">
                        {{ message }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    {% endfor %}
                {% endif %}
                
                {% block content %}
                {% endblock %}
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    {% block extra_js %}
    {% endblock %}
</body>
</html>

# templates/registration/login.html
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema Conselho Tutelar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .login-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .login-header {
            background: #2c3e50;
            color: white;
            border-radius: 15px 15px 0 0;
            padding: 2rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4">
                <div class="login-card">
                    <div class="login-header">
                        <h2>Conselho Tutelar</h2>
                        <p class="mb-0">Sistema de Ocorrências</p>
                    </div>
                    <div class="card-body p-4">
                        {% if form.errors %}
                            <div class="alert alert-danger">
                                Usuário ou senha incorretos.
                            </div>
                        {% endif %}
                        
                        <form method="post">
                            {% csrf_token %}
                            <div class="mb-3">
                                <label for="{{ form.username.id_for_label }}" class="form-label">Usuário</label>
                                {{ form.username }}
                            </div>
                            <div class="mb-3">
                                <label for="{{ form.password.id_for_label }}" class="form-label">Senha</label>
                                {{ form.password }}
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Entrar</button>
                            </div>
                        </form>
                        
                        <hr class="my-4">
                        <div class="text-center">
                            <small class="text-muted">
                                Usuário padrão: <strong>admin</strong><br>
                                Senha padrão: <strong>admin123</strong>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

# templates/ocorrencias/lista.html
{% extends 'base.html' %}
{% load crispy_forms_tags %}

{% block title %}Lista de Ocorrências - Sistema Conselho Tutelar{% endblock %}

{% block content %}
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Ocorrências</h2>
    <a href="{% url 'ocorrencias:nova' %}" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nova Ocorrência
    </a>
</div>

<!-- Filtros -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">
            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#filtros">
                <i class="fas fa-filter"></i> Filtros
            </button>
        </h5>
    </div>
    <div class="collapse" id="filtros">
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Buscar</label>
                    <input type="text" name="q" class="form-control" placeholder="Protocolo, nome, endereço..." value="{{ request.GET.q }}">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="">Todos</option>
                        {% for value, label in status_choices %}
                        <option value="{{ value }}" {% if request.GET.status == value %}selected{% endif %}>{{ label }}</option>
                        {% endfor %}
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Prioridade</label>
                    <select name="prioridade" class="form-select">
                        <option value="">Todas</option>
                        {% for value, label in prioridade_choices %}
                        <option value="{{ value }}" {% if request.GET.prioridade == value %}selected{% endif %}>{{ label }}</option>
                        {% endfor %}
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Bairro</label>
                    <select name="bairro" class="form-select">
                        <option value="">Todos</option>
                        {% for bairro in bairros %}
                        <option value="{{ bairro.id }}" {% if request.GET.bairro == bairro.id|stringformat:"s" %}selected{% endif %}>{{ bairro.nome }}</option>
                        {% endfor %}
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">&nbsp;</label>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-outline-primary">
                            <i class="fas fa-search"></i> Filtrar
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Lista de ocorrências -->
<div class="row">
    {% for ocorrencia in ocorrencias %}
    <div class="col-md-6 col-lg-4 mb-3">
        <div class="card card-ocorrencia h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <strong>{{ ocorrencia.protocolo }}</strong>
                <div>
                    {% if ocorrencia.status == 'registrada' %}
                    <span class="badge bg-secondary status-badge">{{ ocorrencia.get_status_display }}</span>
                    {% elif ocorrencia.status == 'andamento' %}
                    <span class="badge bg-primary status-badge">{{ ocorrencia.get_status_display }}</span>
                    {% elif ocorrencia.status == 'resolvida' %}
                    <span class="badge bg-success status-badge">{{ ocorrencia.get_status_display }}</span>
                    {% else %}
                    <span class="badge bg-warning status-badge">{{ ocorrencia.get_status_display }}</span>
                    {% endif %}
                </div>
            </div>
            <div class="card-body">
                <h6 class="card-title">{{ ocorrencia.nome_crianca }}</h6>
                <p class="card-text text-muted small">
                    <i class="fas fa-map-marker-alt"></i> {{ ocorrencia.endereco }}, {{ ocorrencia.bairro.nome }}
                </p>
                <p class="card-text">
                    {{ ocorrencia.descricao|truncatechars:100 }}
                </p>
                <div class="d-flex justify-content-between align-items-center">
                    <small class="text-muted">
                        <i class="fas fa-clock"></i> {{ ocorrencia.data_registro|date:"d/m/Y H:i" }}
                    </small>
                    {% if ocorrencia.prioridade == 'emergencial' %}
                    <span class="badge bg-danger priority-badge">EMERGENCIAL</span>
                    {% elif ocorrencia.prioridade == 'alta' %}
                    <span class="badge bg-warning priority-badge">ALTA</span>
                    {% endif %}
                </div>
                {% if ocorrencia.conselheira_responsavel %}
                <div class="mt-2">
                    <small class="text-primary">
                        <i class="fas fa-user"></i> {{ ocorrencia.conselheira_responsavel.get_full_name }}
                    </small>
                </div>
                {% endif %}
            </div>
            <div class="card-footer">
                <a href="{% url 'ocorrencias:detalhe' ocorrencia.pk %}" class="btn btn-sm btn-outline-primary">
                    <i class="fas fa-eye"></i> Ver Detalhes
                </a>
                {% if user.perfil == 'admin' or user.perfil == 'coordenador' or ocorrencia.conselheira_responsavel == user %}
                <a href="{% url 'ocorrencias:editar' ocorrencia.pk %}" class="btn btn-sm btn-outline-secondary">
                    <i class="fas fa-edit"></i> Editar
                </a>
                {% endif %}
            </div>
        </div>
    </div>
    {% empty %}
    <div class="col-12">
        <div class="alert alert-info text-center">
            <i class="fas fa-info-circle"></i>
            Nenhuma ocorrência encontrada.
        </div>
    </div>
    {% endfor %}
</div>

<!-- Paginação -->
{% if ocorrencias.has_other_pages %}
<nav aria-label="Paginação">
    <ul class="pagination justify-content-center">
        {% if ocorrencias.has_previous %}
        <li class="page-item">
            <a class="page-link" href="?page={{ ocorrencias.previous_page_number }}{% if request.GET.q %}&q={{ request.GET.q }}{% endif %}">Anterior</a>
        </li>
        {% endif %}
        
        {% for page_num in ocorrencias.paginator.page_range %}
        {% if page_num == ocorrencias.number %}
        <li class="page-item active">
            <span class="page-link">{{ page_num }}</span>
        </li>
        {% else %}
        <li class="page-item">
            <a class="page-link" href="?page={{ page_num }}{% if request.GET.q %}&q={{ request.GET.q }}{% endif %}">{{ page_num }}</a>
        </li>
        {% endif %}
        {% endfor %}
        
        {% if ocorrencias.has_next %}
        <li class="page-item">
            <a class="page-link" href="?page={{ ocorrencias.next_page_number }}{% if request.GET.q %}&q={{ request.GET.q }}{% endif %}">Próxima</a>
        </li>
        {% endif %}
    </ul>
</nav>
{% endif %}
{% endblock %}

# templates/ocorrencias/nova.html
{% extends 'base.html' %}
{% load crispy_forms_tags %}

{% block title %}Nova Ocorrência - Sistema Conselho Tutelar{% endblock %}

{% block content %}
<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card">
            <div class="card-header">
                <h4><i class="fas fa-plus"></i> Nova Ocorrência</h4>
            </div>
            <div class="card-body">
                {% if confirmar_duplicata %}
                <div class="alert alert-warning">
                    <h5><i class="fas fa-exclamation-triangle"></i> Possíveis Ocorrências Similares</h5>
                    <p>Encontramos as seguintes ocorrências que podem estar relacionadas:</p>
                    
                    {% for similar in ocorrencias_similares %}
                    <div class="card mb-2">
                        <div class="card-body">
                            <h6>{{ similar.protocolo }} - {{ similar.nome_crianca }}</h6>
                            <p class="text-muted mb-1">{{ similar.endereco }}, {{ similar.bairro.nome }}</p>
                            <small class="text-muted">{{ similar.data_registro|date:"d/m/Y H:i" }} - {{ similar.get_status_display }}</small>
                        </div>
                    </div>
                    {% endfor %}
                    
                    <p>Deseja continuar com o registro desta nova ocorrência?</p>
                </div>
                {% endif %}
                
                <form method="post" id="formOcorrencia">
                    {% csrf_token %}
                    
                    {% if confirmar_duplicata %}
                    <input type="hidden" name="confirmar_duplicata" value="1">
                    {% endif %}
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Dados da Ocorrência</h5>
                            {{ form.data_ocorrencia|as_crispy_field }}
                            {{ form.endereco|as_crispy_field }}
                            <div class="row">
                                <div class="col-md-6">
                                    {{ form.bairro|as_crispy_field }}
                                </div>
                                <div class="col-md-6">
                                    {{ form.cep|as_crispy_field }}
                                </div>
                            </div>
                            {{ form.complemento|as_crispy_field }}
                            {{ form.prioridade|as_crispy_field }}
                        </div>
                        
                        <div class="col-md-6">
                            <h5>Dados da Criança/Adolescente</h5>
                            {{ form.nome_crianca|as_crispy_field }}
                            {{ form.idade_crianca|as_crispy_field }}
                            {{ form.cpf_crianca|as_crispy_field }}
                            {{ form.responsavel_legal|as_crispy_field }}
                        </div>
                    </div>
                    
                    <hr>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Tipos de Violação</h5>
                            {{ form.tipos_violacao|as_crispy_field }}
                        </div>
                        
                        <div class="col-md-6">
                            <h5>Dados do Denunciante</h5>
                            <div class="form-check mb-3">
                                {{ form.anonimo }}
                                <label class="form-check-label" for="{{ form.anonimo.id_for_label }}">
                                    Denúncia Anônima
                                </label>
                            </div>
                            <div id="dadosDenunciante">
                                {{ form.nome_denunciante|as_crispy_field }}
                                {{ form.telefone_denunciante|as_crispy_field }}
                            </div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <div class="row">
                        <div class="col-12">
                            <h5>Descrição da Ocorrência</h5>
                            {{ form.descricao|as_crispy_field }}
                        </div>
                    </div>
                    
                    <hr>
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="d-flex justify-content-between">
                                <a href="{% url 'ocorrencias:lista' %}" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Voltar
                                </a>
                                
                                {% if confirmar_duplicata %}
                                <div>
                                    <a href="{% url 'ocorrencias:nova' %}" class="btn btn-warning me-2">
                                        <i class="fas fa-times"></i> Cancelar
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-check"></i> Confirmar Registro
                                    </button>
                                </div>
                                {% else %}
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Registrar Ocorrência
                                </button>
                                {% endif %}
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
{% endblock %}

{% block extra_js %}
<script>
// Controlar campos do denunciante baseado no checkbox "anonimo"
document.getElementById('id_anonimo').addEventListener('change', function() {
    const dadosDenunciante = document.getElementById('dadosDenunciante');
    if (this.checked) {
        dadosDenunciante.style.display = 'none';
        document.getElementById('id_nome_denunciante').value = '';
        document.getElementById('id_telefone_denunciante').value = '';
    } else {
        dadosDenunciante.style.display = 'block';
    }
});

// Verificar duplicatas ao alterar endereço, bairro ou nome da criança
let timeoutId;

function verificarDuplicatas() {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(function() {
        const endereco = document.getElementById('id_endereco').value;
        const bairroId = document.getElementById('id_bairro').value;
        const nomeCrianca = document.getElementById('id_nome_crianca').value;
        
        if (endereco && bairroId && nomeCrianca) {
            fetch('{% url "ocorrencias:verificar_duplicatas" %}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
                },
                body: JSON.stringify({
                    endereco: endereco,
                    bairro_id: bairroId,
                    nome_crianca: nomeCrianca
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.similares && data.similares.length > 0) {
                    let alertHtml = '<div class="alert alert-warning alert-dismissible fade show" role="alert">';
                    alertHtml += '<h6><i class="fas fa-exclamation-triangle"></i> Possíveis ocorrências similares encontradas:</h6>';
                    
                    data.similares.forEach(function(similar) {
                        alertHtml += `<p class="mb-1"><strong>${similar.protocolo}</strong> - ${similar.nome_crianca}<br>`;
                        alertHtml += `<small class="text-muted">${similar.endereco} - ${similar.data_registro}</small></p>`;
                    });
                    
                    alertHtml += '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                    alertHtml += '</div>';
                    
                    // Remover alertas anteriores
                    const alertsAnteriores = document.querySelectorAll('.alert-warning:not([class*="confirmar"])');
                    alertsAnteriores.forEach(alert => alert.remove());
                    
                    // Adicionar novo alerta
                    const form = document.getElementById('formOcorrencia');
                    form.insertAdjacentHTML('afterbegin', alertHtml);
                }
            });
        }
    }, 1000);
}

// Adicionar event listeners
document.getElementById('id_endereco').addEventListener('input', verificarDuplicatas);
document.getElementById('id_bairro').addEventListener('change', verificarDuplicatas);
document.getElementById('id_nome_crianca').addEventListener('input', verificarDuplicatas);

// Inicializar estado dos campos do denunciante
document.addEventListener('DOMContentLoaded', function() {
    const anonimo = document.getElementById('id_anonimo');
    if (anonimo.checked) {
        document.getElementById('dadosDenunciante').style.display = 'none';
    }
});
</script>
{% endblock %}

# templates/ocorrencias/detalhe.html
{% extends 'base.html' %}

{% block title %}{{ ocorrencia.protocolo }} - Sistema Conselho Tutelar{% endblock %}

{% block content %}
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4>{{ ocorrencia.protocolo }} - {{ ocorrencia.nome_crianca }}</h4>
                <div>
                    {% if ocorrencia.status == 'registrada' %}
                    <span class="badge bg-secondary">{{ ocorrencia.get_status_display }}</span>
                    {% elif ocorrencia.status == 'andamento' %}
                    <span class="badge bg-primary">{{ ocorrencia.get_status_display }}</span>
                    {% elif ocorrencia.status == 'resolvida' %}
                    <span class="badge bg-success">{{ ocorrencia.get_status_display }}</span>
                    {% else %}
                    <span class="badge bg-warning">{{ ocorrencia.get_status_display }}</span>
                    {% endif %}
                    
                    {% if ocorrencia.prioridade == 'emergencial' %}
                    <span class="badge bg-danger ms-1">EMERGENCIAL</span>
                    {% elif ocorrencia.prioridade == 'alta' %}
                    <span class="badge bg-warning ms-1">ALTA PRIORIDADE</span>
                    {% endif %}
                </div>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6>Dados da Ocorrência</h6>
                        <p><strong>Data da Ocorrência:</strong> {{ ocorrencia.data_ocorrencia|date:"d/m/Y H:i" }}</p>
                        <p><strong>Data de Registro:</strong> {{ ocorrencia.data_registro|date:"d/m/Y H:i" }}</p>
                        <p><strong>Registrado por:</strong> {{ ocorrencia.registrado_por.get_full_name }}</p>
                        <p><strong>Endereço:</strong> {{ ocorrencia.endereco }}{% if ocorrencia.complemento %}, {{ ocorrencia.complemento }}{% endif %}</p>
                        <p><strong>Bairro:</strong> {{ ocorrencia.bairro.nome }}</p>
                        <p><strong>CEP:</strong> {{ ocorrencia.cep }}</p>
                    </div>
                    <div class="col-md-6">
                        <h6>Dados da Criança/Adolescente</h6>
                        <p><strong>Nome:</strong> {{ ocorrencia.nome_crianca }}</p>
                        <p><strong>Idade:</strong> {{ ocorrencia.idade_crianca }} anos</p>
                        {% if ocorrencia.cpf_crianca %}
                        <p><strong>CPF:</strong> {{ ocorrencia.cpf_crianca }}</p>
                        {% endif %}
                        {% if ocorrencia.responsavel_legal %}
                        <p><strong>Responsável Legal:</strong> {{ ocorrencia.responsavel_legal }}</p>
                        {% endif %}
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6>Tipos de Violação</h6>
                        {% for tipo in ocorrencia.tipos_violacao.all %}
                        <span class="badge bg-danger me-1">{{ tipo.nome }}</span>
                        {% endfor %}
                    </div>
                    <div class="col-md-6">
                        <h6>Denunciante</h6>
                        {% if ocorrencia.anonimo %}
                        <p class="text-muted">Denúncia anônima</p>
                        {% else %}
                        {% if ocorrencia.nome_denunciante %}
                        <p><strong>Nome:</strong> {{ ocorrencia.nome_denunciante }}</p>
                        {% endif %}
                        {% if ocorrencia.telefone_denunciante %}
                        <p><strong>Telefone:</strong> {{ ocorrencia.telefone_denunciante }}</p>
                        {% endif %}
                        {% endif %}
                    </div>
                </div>
                
                <div class="mb-4">
                    <h6>Descrição da Ocorrência</h6>
                    <p class="text-justify">{{ ocorrencia.descricao|linebreaksbr }}</p>
                </div>
                
                {% if ocorrencia.conselheira_responsavel %}
                <div class="mb-4">
                    <h6>Responsável pelo Caso</h6>
                    <p>{{ ocorrencia.conselheira_responsavel.get_full_name }}</p>
                    {% if ocorrencia.data_atribuicao %}
                    <p><small class="text-muted">Atribuído em: {{ ocorrencia.data_atribuicao|date:"d/m/Y H:i" }}</small></p>
                    {% endif %}
                </div>
                {% endif %}
            </div>
            <div class="card-footer">
                <a href="{% url 'ocorrencias:lista' %}" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Voltar
                </a>
                {% if user.perfil == 'admin' or user.perfil == 'coordenador' or ocorrencia.conselheira_responsavel == user %}
                <a href="{% url 'ocorrencias:editar' ocorrencia.pk %}" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Editar
                </a>
                {% endif %}
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <!-- Histórico -->
        <div class="card">
            <div class="card-header">
                <h6><i class="fas fa-history"></i> Histórico de Alterações</h6>
            </div>
            <div class="card-body">
                {% if historico %}
                    {% for item in historico %}
                    <div class="border-bottom pb-2 mb-2">
                        <small class="text-muted">{{ item.data_alteracao|date:"d/m/Y H:i" }}</small>
                        <p class="mb-1"><strong>{{ item.usuario.get_full_name }}</strong></p>
                        <p class="mb-1 small">Alterou: {{ item.campo_alterado }}</p>
                        {% if item.observacoes %}
                        <p class="mb-0 small text-muted">{{ item.observacoes }}</p>
                        {% endif %}
                    </div>
                    {% endfor %}
                {% else %}
                    <p class="text-muted">Nenhuma alteração registrada.</p>
                {% endif %}
            </div>
        </div>
        
        <!-- Anexos -->
        <div class="card mt-3">
            <div class="card-header">
                <h6><i class="fas fa-paperclip"></i> Anexos</h6>
            </div>
            <div class="card-body">
                {% if ocorrencia.anexos.all %}
                    {% for anexo in ocorrencia.anexos.all %}
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div>
                            <a href="{{ anexo.arquivo.url }}" target="_blank">{{ anexo.nome_arquivo }}</a>
                            {% if anexo.descricao %}
                            <small class="d-block text-muted">{{ anexo.descricao }}</small>
                            {% endif %}
                        </div>
                        <small class="text-muted">{{ anexo.enviado_em|date:"d/m/Y" }}</small>
                    </div>
                    {% endfor %}
                {% else %}
                    <p class="text-muted">Nenhum anexo.</p>
                {% endif %}
            </div>
        </div>
    </div>
</div>
{% endblock %}

# templates/relatorios/dashboard.html
{% extends 'base.html' %}

{% block title %}Dashboard - Sistema Conselho Tutelar{% endblock %}

{% block content %}
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Dashboard</h2>
    <div class="text-muted">
        <i class="fas fa-calendar"></i> {{ "now"|date:"d/m/Y" }}
    </div>
</div>

<!-- Cards de estatísticas -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4>{{ total_ocorrencias }}</h4>
                        <p class="mb-0">Total de Ocorrências</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-clipboard-list fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card text-white bg-info">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4>{{ ocorrencias_mes }}</h4>
                        <p class="mb-0">Este Mês</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-calendar-month fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4>{{ ocorrencias_pendentes }}</h4>
                        <p class="mb-0">Pendentes</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-clock fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card text-white bg-success">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4>{{ ocorrencias_resolvidas }}</h4>
                        <p class="mb-0">Resolvidas</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-check-circle fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Gráfico de ocorrências por status -->
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h6><i class="fas fa-chart-pie"></i> Ocorrências por Status</h6>
            </div>
            <div class="card-body">
                <canvas id="statusChart"></canvas>
            </div>
        </div>
    </div>
    
    <!-- Top 5 tipos de violação -->
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h6><i class="fas fa-exclamation-triangle"></i> Principais Tipos de Violação</h6>
            </div>
            <div class="card-body">
                {% for tipo in tipo_stats %}
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span>{{ tipo.nome }}</span>
                    <div>
                        <span class="badge bg-secondary">{{ tipo.count }}</span>
                        <div class="progress" style="width: 100px; height: 6px;">
                            <div class="progress-bar" style="width: {% widthratio tipo.count tipo_stats.0.count 100 %}%"></div>
                        </div>
                    </div>
                </div>
                {% endfor %}
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <!-- Carga de trabalho das conselheiras -->
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h6><i class="fas fa-users"></i> Carga de Trabalho - Conselheiras</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Conselheira</th>
                                <th>Casos Ativos</th>
                                <th>Casos Resolvidos</th>
                                <th>Total</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {% for conselheira in conselheiras_stats %}
                            <tr>
                                <td>{{ conselheira.get_full_name }}</td>
                                <td>
                                    <span class="badge bg-primary">{{ conselheira.casos_ativos }}</span>
                                </td>
                                <td>
                                    <span class="badge bg-success">{{ conselheira.casos_resolvidos }}</span>
                                </td>
                                <td>{{ conselheira.casos_ativos|add:conselheira.casos_resolvidos }}</td>
                                <td>
                                    {% if conselheira.ativo %}
                                    <span class="badge bg-success">Ativa</span>
                                    {% else %}
                                    <span class="badge bg-secondary">Inativa</span>
                                    {% endif %}
                                </td>
                            </tr>
                            {% endfor %}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}

{% block extra_js %}
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Gráfico de status
const statusCtx = document.getElementById('statusChart').getContext('2d');
const statusChart = new Chart(statusCtx, {
    type: 'doughnut',
    data: {
        labels: [{% for status in status_stats %}'{{ status.status|capfirst }}'{% if not forloop.last %},{% endif %}{% endfor %}],
        datasets: [{
            data: [{% for status in status_stats %}{{ status.count }}{% if not forloop.last %},{% endif %}{% endfor %}],
            backgroundColor: [
                '#6c757d', // registrada
                '#007bff', // andamento  
                '#28a745', // resolvida
                '#ffc107', // aguardando
                '#17a2b8', // encaminhada
                '#6f42c1'  // arquivada
            ]
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});
</script>
{% endblock %}